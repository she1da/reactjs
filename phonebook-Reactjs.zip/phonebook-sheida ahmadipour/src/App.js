import React, { useEffect, useState } from "react";
import List from "./components/list";
import Panel from "./components/panel";
import UpdateList from "./components/updateList";
export default function App() {
  const intialUser = [{ name: "Sheida", number: "+98-9389845634", id: 1 }];
  const [phonebook, setPhoneBook] = useState(intialUser);
  const [contact, setContact] = useState({ name: "", number: "", id: null });
  const [keyword, setKeyword] = useState("");
  const [mode, setMode] = useState("save");
  const [updateview, setUpdateView] = useState("list");
  const [SearchResult, setSearchResult] = useState([]);

  useEffect(() => {
    if (keyword !== "") {
      setSearchResult(
        phonebook.filter((item) =>
          item.name.toLowerCase().includes(keyword.toLowerCase())
        )
      );
    }
  }, [keyword]);

  useEffect(() => {
    if (updateview === "list") {
      setContact({ name: "", number: "", id: null });
    }
  }, [updateview]);

  function handleEdit() {
    const UpdatedData = phonebook.map((item) => {
      if (item.id === contact.id) {
        console.log(item.id, "item");
        return {
          ...item,
          name: contact.name,
          number: contact.number,
          id: item.id,
        };
      }
      return item;
    });
    setPhoneBook(UpdatedData);
    setUpdateView("list");
  }
  function handleDelete(id) {
    const UpdatedData = phonebook.filter((item) => item.id !== id);
    setPhoneBook(UpdatedData);
  }

  function handleAdd() {
    setMode("save");
    setUpdateView("update");
  }

  function handleBTNEdit(id) {
    phonebook.map((item) => {
      if (item.id === id) {
        setContact(item);
      }
    });
    setUpdateView("update");
    setMode("edit");
  }
  function handleSearch(e) {
    setKeyword(e.target.value);
  }

  function handleName(e) {
    setContact({ ...contact, name: e.target.value });
  }
  function handleNumber(e) {
    setContact({ ...contact, number: e.target.value });
  }

  function handleSave(e) {
    const newId = Math.random() * 100;
    setPhoneBook((prev) => [
      ...prev,
      {
        name: contact.name,
        number: contact.number,
        id: newId,
      },
    ]);
    setUpdateView("list");
  }
  function handleCancel() {
    setUpdateView("list");
  }
  return (
    <div className="container">
      {updateview === "update" ? (
        <div>
          <UpdateList
            contact={contact}
            NameChange={handleName}
            NumberChange={handleNumber}
            onSave={handleSave}
            onEdit={handleEdit}
            onCancel={handleCancel}
            mode={mode}
          />
        </div>
      ) : (
        <div>
          <Panel
            onAddClick={handleAdd}
            keyword={keyword}
            onSearchChange={handleSearch}
          />

          <List
            phonebook={keyword !== "" ? SearchResult : phonebook}
            onBtnEdit={handleBTNEdit}
            onDelete={handleDelete}
          />
        </div>
      )}
    </div>
  );
}
