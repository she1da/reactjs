import React from "react";
export default function UpdateList({
  contact,
  NameChange,
  NumberChange,
  onSave,
  onEdit,
  onCancel,
  mode,
}) {
  console.log("render");
  return (
    <div className="p-5">
      <input
        type="text"
        className="form-control mb-3"
        id="name"
        placeholder="name"
        value={contact.name}
        onChange={NameChange}
      />
      <input
        type="number"
        className="form-control"
        id="number"
        placeholder="phone"
        value={contact.number}
        onChange={NumberChange}
      />
      {mode === "save" ? (
        <button
          className="btn btn-lg btn-success btn-block mt-4"
          onClick={onSave}
        >
          save
        </button>
      ) : (
        <button
          className="btn btn-lg btn-warning btn-block mt-4"
          onClick={onEdit}
        >
          Edit
        </button>
      )}
      <button
        className="btn btn-lg btn-danger btn-block mt-4"
        onClick={onCancel}
      >
        Cancel
      </button>
    </div>
  );
}
