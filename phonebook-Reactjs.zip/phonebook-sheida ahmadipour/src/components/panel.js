import React from "react";
import Search from "./search";
export default function Panel({ onAddClick, onSearchChange, keyword }) {
  return (
    <div className="p-2">
      <p className="mt-5 mb-3 text-muted">phonebook</p>
      <Search onSearchChange={onSearchChange} keyword={keyword} />
      <button
        className="btn btn-lg btn-success btn-block "
        onClick={onAddClick}
      >
        Add
      </button>
    </div>
  );
}
