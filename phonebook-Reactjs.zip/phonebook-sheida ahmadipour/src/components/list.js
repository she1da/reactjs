import React from "react";
import Row from "./row";
export default function List({ phonebook, onDelete, onBtnEdit }) {
  const listItems = phonebook.map((item) => {
    return (
      <Row
        phonebook={phonebook}
        onDelete={() => onDelete(item.id)}
        onBtnEdit={() => onBtnEdit(item.id)}
        key={item.id}
        contactName={item.name}
        number={item.number}
        id={item.id}
      />
    );
  });
  return (
    <div className="p-5">
      <ul className="list-group">
        <li
          key="title"
          className="list-group-item d-flex justify-content-between align-items-center"
        >
          <span>Name</span>
          <span> Phone</span>
          <span></span>
          <span></span>
        </li>
        {listItems}
      </ul>
    </div>
  );
}
