import React from "react";
export default function Search({ keyword, onSearchChange }) {
  return (
    <div className="mb-3">
      <input
        className="form-control"
        type="search"
        placeholder="search"
        value={keyword}
        onChange={onSearchChange}
      />
    </div>
  );
}
