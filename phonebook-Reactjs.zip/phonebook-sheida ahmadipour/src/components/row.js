import React from "react";
export default function Row({ contactName, number, onDelete, onBtnEdit }) {
  return (
    <li className="list-group-item d-flex justify-content-between align-items-center">
      <span>{contactName}</span>
      <span> {number}</span>
      <button className="btn btn-warning" onClick={onBtnEdit}>
        Edit
      </button>
      <button className="btn btn-danger" onClick={onDelete}>
        Delete
      </button>
    </li>
  );
}
